#include <ArduinoJson.h>
#include <catch.hpp>

using namespace ArduinoJson;

static std::string readAll(Stream& stream, size_t chunkSize) {
  std::string out;
  std::vector<char> buf(chunkSize);

  while (true) {
    size_t n = stream.readBytes(buf.data(), buf.size());
    if (n == 0)
      break;
    out.append(buf.data(), n);
  }

  return out;
}

TEST_CASE("JsonSerializerStream serializes object incrementally") {
  JsonDocument doc;
  doc["hello"] = "world";
  doc["answer"] = 42;
  doc["ok"] = true;

  JsonSerializerStream stream(std::move(doc));

  REQUIRE(readAll(stream, 4) == "{\"hello\":\"world\",\"answer\":42,\"ok\":true}");
}

TEST_CASE("JsonSerializerStream serializes nested arrays and objects") {
  JsonDocument doc;
  JsonArray arr = doc["items"].to<JsonArray>();
  arr.add(1);
  arr.add(2);
  JsonObject nested = arr.add<JsonObject>();
  nested["x"] = 3;

  JsonSerializerStream stream(std::move(doc));

  REQUIRE(readAll(stream, 3) == "{\"items\":[1,2,{\"x\":3}]}");
}

TEST_CASE("JsonSerializerStream escapes strings") {
  JsonDocument doc;
  doc["text"] = "a\"b\\c\nd";

  JsonSerializerStream stream(std::move(doc));

  REQUIRE(readAll(stream, 2) == "{\"text\":\"a\\\"b\\\\c\\nd\"}");
}

TEST_CASE("JsonSerializerStream serializes null and bool") {
  JsonDocument doc;
  doc["a"] = nullptr;
  doc["b"] = false;
  doc["c"] = true;

  JsonSerializerStream stream(std::move(doc));

  REQUIRE(readAll(stream, 5) == "{\"a\":null,\"b\":false,\"c\":true}");
}

TEST_CASE("JsonSerializerStream serializes integers") {
  JsonDocument doc;
  JsonArray arr = doc.to<JsonArray>();
  arr.add(-1);
  arr.add(0);
  arr.add(1);
  arr.add(123456);

  JsonSerializerStream stream(std::move(doc));

  REQUIRE(readAll(stream, 2) == "[-1,0,1,123456]");
}

TEST_CASE("JsonSerializerStream serializes floats") {
  JsonDocument doc;
  JsonArray arr = doc.to<JsonArray>();
  arr.add(1.5);
  arr.add(-2.25);

  JsonSerializerStream stream(std::move(doc));
  auto s = readAll(stream, 3);

  REQUIRE(s[0] == '[');
  REQUIRE(s.find("1.5") != std::string::npos);
  REQUIRE(s.find("-2.25") != std::string::npos);
  REQUIRE(s.back() == ']');
}

TEST_CASE("JsonSerializerStream supports chunk boundaries inside string escape") {
  JsonDocument doc;
  doc["x"] = "\"";

  JsonSerializerStream stream(std::move(doc));

  REQUIRE(readAll(stream, 1) == "{\"x\":\"\\\"\"}");
}

TEST_CASE("JsonSerializerStream supports raw strings") {
  JsonDocument doc;
  doc.set(serialized("{\"nested\":true}"));

  JsonSerializerStream stream(std::move(doc));

  REQUIRE(readAll(stream, 4) == "{\"nested\":true}");
}

TEST_CASE("JsonSerializerStream read/peek/end-of-stream") {
  JsonDocument doc;
  doc.set(42);

  JsonSerializerStream stream(std::move(doc));

  REQUIRE(stream.peek() == '4');
  REQUIRE(stream.read() == '4');
  REQUIRE(stream.read() == '2');
  REQUIRE(stream.read() == -1);
  REQUIRE(stream.peek() == -1);
  REQUIRE(stream.available() == 0);
}